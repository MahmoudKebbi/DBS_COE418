package com.Accounts;

public class StaffAccount {
    protected String staffUsername;
    protected String staffPassword;

    public StaffAccount(String staffUsername, String staffPassword) {
        this.staffUsername = staffUsername;
        this.staffPassword = staffPassword;
    }

    public String getStaffUsername() {
        return staffUsername;
    }

    public void setStaffUsername(String staffUsername) {
        this.staffUsername = staffUsername;
    }

    public String getStaffPassword() {
        return staffPassword;
    }

    public void setStaffPassword(String staffPassword) {
        this.staffPassword = staffPassword;
    }
}
