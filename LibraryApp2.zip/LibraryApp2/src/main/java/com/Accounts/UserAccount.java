package com.Accounts;

import com.People.*;

import java.net.URL;
import java.sql.*;
import java.util.*;
import java.util.Date;

import com.libraryapp2.controller.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

public class UserAccount {

    static Statement stmt;

    static {
        try {
            stmt = MySQLConnector.statement();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    protected String userUsername;
    protected String userPassword;

    public String getUserUsername() {
        return userUsername;
    }

    public void setUserUsername(String userUsername) {
        this.userUsername = userUsername;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public UserAccount(String userUsername, String userPassword) throws SQLException {
        this.userUsername = userUsername;
        this.userPassword = userPassword;
    }
    public static void add_new_user(String username, String password, String firstName, String lastName, int phoneNumber, int landline, String email,
                                    Date dateOfBirth, Person.Gender gen, String nationality, String city,String street, String building) throws SQLException {
        String sqlInsert = "insert into newlibrarydb.users (firstName,lastName,phoneNumber,landline,email,dateOfBirth,gender,nationality,street,city,building) values" + " ('" + firstName + "'," + "'" + lastName + "'," + "'" + phoneNumber +"'"+ ",'"+landline +"',"+email+"'," +"STR_TO_DATE(\"" + dateOfBirth + "\", \"%d-%m-%Y\")" + "," + "'"+gen+"'"+"," + "'"+nationality+"'"+"," + "'"+street+"'"+"," + "'"+city+"'"+"," + "'"+building+"'"+")";
        stmt.executeUpdate(sqlInsert);
        sqlInsert = "insert into newlibrarydb.useraccount (username,password) values"+"('"+username+"','"+password+"'";
        stmt.executeUpdate(sqlInsert);


    }
    public static boolean validate_user(String username, String password) throws SQLException {

        String sqlselect= "SELECT * from useraccount WHERE username = '" +username+"'";

        ResultSet rs =stmt.executeQuery(sqlselect);
        rs.next();
        String passcode = rs.getString("password");

        boolean login=(Objects.equals(password, passcode));

        return login;


        //should check if a given account is available in the database

    }

    public static boolean username_not_exists(String username) throws SQLException {
        int count = 0;
        String sqlselect = "SELECT Exists(Select * from useraccount where username ='" + username + "')";
        ResultSet rs = stmt.executeQuery(sqlselect);
        while (rs.next()) {
            count = rs.getInt(1);
        }
        return count == 0;
    }
    public static boolean email_not_exists(String email) throws SQLException {
        int count = 0;
        String sqlselect = "SELECT Exists(Select * from users where email ='" + email + "')";
        ResultSet rs = stmt.executeQuery(sqlselect);
        while (rs.next()) {
            count = rs.getInt(1);
        }
        return count == 0;
    }
    public static void delete_user(int id) throws SQLException {
    String sqldelete = "delete from librarydb.accounts where userId ='" + id + "')";
    ResultSet rs = stmt.executeQuery(sqldelete);
    }











//    public void initialize(URL url, ResourceBundle rb) {
//
//        col_username.setCellValueFactory(new PropertyValueFactory<Book,Integer>("ISBN"));
//        col_firstName.setCellValueFactory(new PropertyValueFactory<Book,String>("title"));
//        col_lastName.setCellValueFactory(new PropertyValueFactory<Book,String>("author"));
//        col_publisher.setCellValueFactory(new PropertyValueFactory<Book,String>("publisher"));
//        col_edition.setCellValueFactory(new PropertyValueFactory<Book,Integer>("edition"));
//        col_pubdate.setCellValueFactory(new PropertyValueFactory<Book,String>("pubdate"));
//        col_genre1.setCellValueFactory(new PropertyValueFactory<Book,String>("genre1"));
//        listM= mysqlconnect.getDataBooks();
//        System.out.println(listM.toString());
//        tableBooks.setItems(listM);
//
//    }


//public static ObservableList<Book> getDataBooks(){
//    Connection conn = Connectdb();
//    ObservableList<Book> list = FXCollections.observableArrayList();
//    try{
//        PreparedStatement pst = conn.prepareStatement("select * from book");
//        ResultSet rs = pst.executeQuery();
//        while(rs.next()){
//            list.add(new Book(rs.getInt("ISBN"),rs.getString("title"),
//                    rs.getString("author"),rs.getString("publisher"),
//                    rs.getInt("edition"), rs.getString("pubdate"),rs.getString("genre1") ));
//        }
//    } catch (Exception  e) {
//
//    }
//    return list;
//}
}
