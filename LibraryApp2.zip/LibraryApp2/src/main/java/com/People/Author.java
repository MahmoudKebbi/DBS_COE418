package com.People;

import java.util.Date;

public class Author {
    protected int authorId;
    protected String firstName;
    protected String lastName;
    protected int landLine;
    protected String email;
    protected Date dateOfBirth;
    protected enum gender {MALE,FEMALE};
    protected String nationality;

    public int getAuthorId() {
        return authorId;
    }

    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getLandLine() {
        return landLine;
    }

    public void setLandLine(int landLine) {
        this.landLine = landLine;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public Author(int authorId, String firstName, String lastName, int landLine, String email, Date dateOfBirth, String nationality) {
        this.authorId = authorId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.landLine = landLine;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.nationality = nationality;
    }
}
