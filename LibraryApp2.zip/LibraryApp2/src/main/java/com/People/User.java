package com.People;

import java.util.Date;

public class User extends Person {
    public User(int accountId, String firstName, String lastName, int phoneNumber, int landLine, String email, Date dateOfBirth, String nationality, String street, String city, String building, Date dateAdded) {
        super(accountId, firstName, lastName, phoneNumber, landLine, email, dateOfBirth, nationality, street, city, building, dateAdded);
    }

}
