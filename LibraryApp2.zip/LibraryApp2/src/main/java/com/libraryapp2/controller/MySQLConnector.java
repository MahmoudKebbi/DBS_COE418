package com.libraryapp2.controller;

import javax.swing.*;
import java.sql.*;

public class MySQLConnector {

    public static Connection connect(){
        try{

            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb","root","Beirut-2003");
            JOptionPane.showMessageDialog(null,"Connection Established");
            return conn;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null , e);
            return null;

        }

    }

    public static Statement statement() throws SQLException{

        Statement stmt = connect().createStatement();
        return stmt;
    }

    public static void main(String [] args) throws SQLException {
        connect();

        Statement stmt = statement();

    }
}

