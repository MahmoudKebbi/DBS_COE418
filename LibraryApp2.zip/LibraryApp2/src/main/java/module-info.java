module com.example.libraryapp2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;


    opens com.example.libraryapp2 to javafx.fxml;
    exports com.example.libraryapp2;
}